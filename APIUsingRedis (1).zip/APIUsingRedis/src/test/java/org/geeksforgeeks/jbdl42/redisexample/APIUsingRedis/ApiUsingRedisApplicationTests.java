package org.geeksforgeeks.jbdl42.redisexample.APIUsingRedis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiUsingRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
