package org.geeksforgeeks.jbdl42.sbjpaexample.SpringBootJPAExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
