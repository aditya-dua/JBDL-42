package org.geeksforgeeks.jbdl.springboothibernateexample.SpringbootWithHibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWithHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
